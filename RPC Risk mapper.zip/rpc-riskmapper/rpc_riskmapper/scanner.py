"""
scanner.py - Network scanning module using Nmap.
Scans target systems for RPC-related ports and services.
"""

import subprocess
import xml.etree.ElementTree as ET
import json
import logging
import shutil
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict

logger = logging.getLogger(__name__)


@dataclass
class PortResult:
    port: int
    protocol: str
    state: str
    service: str
    version: str
    product: str
    extra_info: str = ""
    scripts: Dict[str, str] = field(default_factory=dict)


@dataclass
class ScanResult:
    target: str
    ip_address: str
    hostname: str
    os_guess: str
    scan_time: str
    ports: List[PortResult] = field(default_factory=list)
    raw_output: str = ""
    success: bool = True
    error: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def get_open_ports(self) -> List[PortResult]:
        return [p for p in self.ports if p.state == "open"]

    def has_rpc(self) -> bool:
        return any(p.port == 135 and p.state == "open" for p in self.ports)


# Standard RPC-related ports
RPC_PORTS = [135, 139, 445, 593, 49152, 49153, 49154, 49155, 49156, 49157, 49158]


class NetworkScanner:
    """Nmap-based network scanner focused on RPC services."""

    def __init__(self, nmap_path: Optional[str] = None, timeout: int = 300):
        self.nmap_path = nmap_path or self._find_nmap()
        self.timeout = timeout

    def _find_nmap(self) -> str:
        """Locate nmap binary."""
        nmap = shutil.which("nmap")
        if nmap:
            return nmap
        # Common Windows paths
        common = [
            r"C:\Program Files (x86)\Nmap\nmap.exe",
            r"C:\Program Files\Nmap\nmap.exe",
        ]
        for p in common:
            import os
            if os.path.isfile(p):
                return p
        raise FileNotFoundError(
            "Nmap not found. Install from https://nmap.org/download.html "
            "and ensure it is in your PATH."
        )

    def scan(self, target: str, ports: Optional[List[int]] = None,
             aggressive: bool = False, scripts: bool = True) -> ScanResult:
        """
        Run an Nmap scan against the target.

        Args:
            target: IP address or hostname
            ports: List of ports to scan (defaults to RPC_PORTS)
            aggressive: Enable OS detection and version intensity
            scripts: Run default NSE scripts for RPC
        """
        scan_ports = ports or RPC_PORTS
        port_str = ",".join(str(p) for p in scan_ports)

        cmd = [
            self.nmap_path,
            "-sV",                    # Version detection
            "-p", port_str,
            "-oX", "-",               # XML output to stdout
            "--host-timeout", str(self.timeout),
        ]

        if aggressive:
            cmd.extend(["-O", "--version-intensity", "9", "-A"])

        if scripts:
            cmd.extend([
                "--script",
                "msrpc-enum,rpc-grind,rpcinfo,smb-os-discovery,smb-protocols"
            ])

        cmd.append(target)

        logger.info(f"Running: {' '.join(cmd)}")

        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True,
                timeout=self.timeout + 30
            )
            if proc.returncode not in (0, 1):  # 1 = host down but valid
                return ScanResult(
                    target=target, ip_address=target, hostname="",
                    os_guess="", scan_time="",
                    success=False, error=proc.stderr.strip()
                )
            return self._parse_xml(target, proc.stdout)

        except subprocess.TimeoutExpired:
            return ScanResult(
                target=target, ip_address=target, hostname="",
                os_guess="", scan_time="",
                success=False, error="Scan timed out"
            )
        except Exception as e:
            return ScanResult(
                target=target, ip_address=target, hostname="",
                os_guess="", scan_time="",
                success=False, error=str(e)
            )

    def _parse_xml(self, target: str, xml_data: str) -> ScanResult:
        """Parse Nmap XML output into ScanResult."""
        try:
            root = ET.fromstring(xml_data)
        except ET.ParseError as e:
            return ScanResult(
                target=target, ip_address=target, hostname="",
                os_guess="", scan_time="",
                success=False, error=f"XML parse error: {e}"
            )

        host = root.find(".//host")
        if host is None:
            return ScanResult(
                target=target, ip_address=target, hostname="",
                os_guess="", scan_time="",
                success=False, error="No host found in scan results"
            )

        # Extract address
        addr_el = host.find("address[@addrtype='ipv4']")
        ip = addr_el.get("addr", target) if addr_el is not None else target

        # Extract hostname
        hostname_el = host.find(".//hostname")
        hostname = hostname_el.get("name", "") if hostname_el is not None else ""

        # Extract OS guess
        os_guess = ""
        os_match = host.find(".//osmatch")
        if os_match is not None:
            os_guess = f"{os_match.get('name', '')} ({os_match.get('accuracy', '')}%)"

        # Scan time
        scan_time = root.get("startstr", "")

        # Parse ports
        ports = []
        for port_el in host.findall(".//port"):
            state_el = port_el.find("state")
            service_el = port_el.find("service")

            state = state_el.get("state", "unknown") if state_el is not None else "unknown"
            service = service_el.get("name", "unknown") if service_el is not None else "unknown"
            product = service_el.get("product", "") if service_el is not None else ""
            version = service_el.get("version", "") if service_el is not None else ""
            extra = service_el.get("extrainfo", "") if service_el is not None else ""

            # Collect script outputs
            scripts = {}
            for script_el in port_el.findall("script"):
                scripts[script_el.get("id", "")] = script_el.get("output", "")

            ports.append(PortResult(
                port=int(port_el.get("portid", 0)),
                protocol=port_el.get("protocol", "tcp"),
                state=state,
                service=service,
                version=version,
                product=product,
                extra_info=extra,
                scripts=scripts,
            ))

        return ScanResult(
            target=target,
            ip_address=ip,
            hostname=hostname,
            os_guess=os_guess,
            scan_time=scan_time,
            ports=ports,
            raw_output=xml_data,
            success=True,
        )

    def quick_check(self, target: str) -> bool:
        """Quick check if port 135 is open on target."""
        result = self.scan(target, ports=[135], aggressive=False, scripts=False)
        return result.has_rpc()
