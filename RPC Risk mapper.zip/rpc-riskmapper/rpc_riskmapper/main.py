#!/usr/bin/env python3
"""
RPC RiskMapper - Main CLI Entry Point
RPC-based Network Risk Assessment with CVSS Vulnerability Scoring
"""

import argparse
import sys
import os
import logging
from pathlib import Path

if __name__ == "__main__" and __package__ is None:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rpc_riskmapper.scanner import NetworkScanner, ScanResult, PortResult
from rpc_riskmapper.rpc_enum import RPCEnumerator
from rpc_riskmapper.vuln_lookup import VulnerabilityLookup
from rpc_riskmapper.analyzer import RiskAnalyzer
from rpc_riskmapper.recommender import RecommendationEngine
from rpc_riskmapper.reporter import ConsoleReporter, JSONReporter, HTMLReporter


def parse_args():
    parser = argparse.ArgumentParser(
        prog="rpc-riskmapper",
        description="RPC RiskMapper - RPC-based Network Risk Assessment with CVSS Scoring",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  rpc-riskmapper 192.168.1.10
  rpc-riskmapper 10.0.0.1 --aggressive --json report.json
  rpc-riskmapper dc01.corp.local -u admin -p pass -d CORP --html report.html
  rpc-riskmapper 192.168.1.10 --no-color --json results.json
  rpc-riskmapper 10.0.0.5 --nvd-api-key YOUR_KEY --use-nvd
  rpc-riskmapper 192.168.1.10 --offline
        """
    )

    parser.add_argument("target", help="Target IP address, hostname, or CIDR range")

    scan_group = parser.add_argument_group("Scan Options")
    scan_group.add_argument("--ports", "-p", help="Additional ports to scan (comma-separated)", default="")
    scan_group.add_argument("--aggressive", "-A", action="store_true", help="Enable aggressive scan")
    scan_group.add_argument("--timeout", type=int, default=300, help="Scan timeout in seconds (default: 300)")
    scan_group.add_argument("--no-scripts", action="store_true", help="Disable NSE scripts")
    scan_group.add_argument("--nmap-path", help="Custom path to nmap binary")
    scan_group.add_argument("--offline", action="store_true", help="Skip network scan, use RPC enumeration only")

    auth_group = parser.add_argument_group("Authentication")
    auth_group.add_argument("--username", "-u", default="", help="Username for authenticated RPC enumeration")
    auth_group.add_argument("--password", "-P", default="", help="Password for authenticated RPC enumeration")
    auth_group.add_argument("--domain", "-d", default="", help="Domain for authenticated RPC enumeration")

    vuln_group = parser.add_argument_group("Vulnerability Lookup")
    vuln_group.add_argument("--use-nvd", action="store_true", help="Enable NVD API enrichment")
    vuln_group.add_argument("--nvd-api-key", default="", help="NVD API key for higher rate limits")
    vuln_group.add_argument("--custom-db", help="Path to custom CVE database (JSON)")

    out_group = parser.add_argument_group("Output")
    out_group.add_argument("--json", dest="json_output", help="Export results to JSON file")
    out_group.add_argument("--html", dest="html_output", help="Export results to HTML file")
    out_group.add_argument("--no-color", action="store_true", help="Disable colored output")
    out_group.add_argument("--quiet", "-q", action="store_true", help="Suppress banner and verbose output")
    out_group.add_argument("--verbose", "-v", action="count", default=0, help="Increase verbosity (-v, -vv)")

    return parser.parse_args()


def setup_logging(verbosity: int):
    level = logging.WARNING
    if verbosity >= 2:
        level = logging.DEBUG
    elif verbosity >= 1:
        level = logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


def run_assessment(args) -> int:
    """Run the full RPC risk assessment pipeline. Returns exit code."""

    setup_logging(args.verbose)
    logger = logging.getLogger("rpc_riskmapper")

    console = ConsoleReporter(no_color=args.no_color)

    if not args.quiet:
        console.print_banner()

    # ── Phase 1: Network Scan ──
    scan_result = None
    if not args.offline:
        try:
            print("  [*] Phase 1: Network Scanning...")
            scanner = NetworkScanner(
                nmap_path=args.nmap_path,
                timeout=args.timeout,
            )
            extra_ports = []
            if args.ports:
                extra_ports = [int(p.strip()) for p in args.ports.split(",") if p.strip()]

            scan_result = scanner.scan(
                target=args.target,
                ports=extra_ports if extra_ports else None,
                aggressive=args.aggressive,
                scripts=not args.no_scripts,
            )

            if not scan_result.success:
                print(f"  [!] Scan warning: {scan_result.error}")
                print("  [*] Continuing with RPC enumeration...")
            else:
                console.print_scan_results(scan_result)

        except FileNotFoundError as e:
            print(f"  [!] {e}")
            print("  [*] Continuing without Nmap scan...")
        except Exception as e:
            print(f"  [!] Scan error: {e}")
            print("  [*] Continuing with RPC enumeration...")
    else:
        print("  [*] Phase 1: Skipped (offline mode)")

    # ── Phase 2: RPC Enumeration ──
    print("  [*] Phase 2: RPC Endpoint Enumeration...")
    enumerator = RPCEnumerator()
    rpc_result = enumerator.enumerate(
        target=args.target,
        username=args.username,
        password=args.password,
        domain=args.domain,
    )

    # Hard stop if host is unreachable
    if not rpc_result.host_reachable and not rpc_result.success:
        print(f"\n  [!] {rpc_result.error}")
        print("  [!] Aborting assessment — cannot assess a host with no response.")
        print("       Verify the target IP is correct and that you have network access.")
        print()
        print("  ── Basic Precautions & Troubleshooting ─────────────────────────────")
        print()
        print("  1. Verify the target IP / hostname")
        print("       ping <target>  — confirms basic ICMP reachability")
        print("       nslookup <hostname>  — resolves hostname to IP")
        print()
        print("  2. Check your own network connection")
        print("       Make sure your machine has a valid IP and default gateway.")
        print("       Try reaching a known-good host on the same subnet first.")
        print()
        print("  3. Firewall may be blocking you")
        print("       Windows Firewall on the target might be dropping inbound probes.")
        print("       Ask the admin to allow TCP 135 / 445 from your scanner IP,")
        print("       or run the scan from inside the same network segment.")
        print()
        print("  4. Host may be offline or powered down")
        print("       Confirm the device is powered on and its NIC is active.")
        print()
        print("  5. VPN / routing issue")
        print("       If scanning across a VPN, ensure split-tunnelling isn't")
        print("       blocking traffic to the target subnet.")
        print("       Try: tracert <target>  to see where routing stops.")
        print()
        print("  6. Wrong subnet / VLAN")
        print("       The target may be in an isolated VLAN with no route to you.")
        print("       Check with your network team that the scanner has access.")
        print()
        print("  7. Try --offline mode for a worst-case theoretical assessment")
        print("       rpc-riskmapper <target> --offline")
        print("       This skips all probing and returns standard Windows RPC")
        print("       exposure assumptions — useful for planning, not for audits.")
        print()
        print("  ────────────────────────────────────────────────────────────────────")
        return 0

    if rpc_result.success:
        console.print_rpc_results(rpc_result)
    else:
        print(f"  [!] RPC enumeration warning: {rpc_result.error}")

    # ── Phase 3: Vulnerability Lookup ──
    print("  [*] Phase 3: Vulnerability Analysis...")
    vuln_lookup = VulnerabilityLookup(
        nvd_api_key=args.nvd_api_key,
        use_nvd=args.use_nvd,
        custom_db_path=args.custom_db,
    )
    vulnerabilities = vuln_lookup.lookup(
        rpc_result.services,
        confirmed_only=not rpc_result.inferred,
    )
    console.print_vulnerabilities(vulnerabilities, inferred=rpc_result.inferred)

    # ── Phase 4: Risk Analysis ──
    print("  [*] Phase 4: Risk Assessment...")
    analyzer = RiskAnalyzer()
    risk_summary = analyzer.analyze(
        target=args.target,
        vulnerabilities=vulnerabilities,
        scan_result=scan_result,
        rpc_result=rpc_result,
    )
    console.print_risk_summary(risk_summary, inferred=rpc_result.inferred)

    # ── Phase 5: Recommendations ──
    print("  [*] Phase 5: Generating Recommendations...")
    recommender = RecommendationEngine()
    recommendations = recommender.generate(risk_summary, vulnerabilities)
    exec_summary = recommender.get_executive_summary(risk_summary, recommendations)
    console.print_recommendations(recommendations, exec_summary)

    # ── Export Reports ──
    if args.json_output:
        json_reporter = JSONReporter()
        json_reporter.export(
            args.json_output, args.target,
            scan_result, rpc_result, vulnerabilities,
            risk_summary, recommendations, exec_summary,
        )
        print(f"\n  [✓] JSON report saved to: {args.json_output}")

    if args.html_output:
        html_reporter = HTMLReporter()
        html_reporter.export(
            args.html_output, args.target,
            scan_result, rpc_result, vulnerabilities,
            risk_summary, recommendations, exec_summary,
        )
        print(f"  [✓] HTML report saved to: {args.html_output}")

    exit_codes = {
        "CRITICAL": 4, "HIGH": 3, "MEDIUM-HIGH": 2,
        "MEDIUM": 2, "LOW": 1, "INFORMATIONAL": 0,
    }
    return exit_codes.get(risk_summary.overall_risk_level, 0)


def main():
    args = parse_args()
    try:
        exit_code = run_assessment(args)
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n  [!] Scan interrupted by user.")
        sys.exit(130)
    except Exception as e:
        print(f"\n  [!] Fatal error: {e}")
        logging.getLogger().debug("Stack trace:", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
