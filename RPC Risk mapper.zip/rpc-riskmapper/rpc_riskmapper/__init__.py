"""RPC RiskMapper."""
__version__ = "1.0.0"
