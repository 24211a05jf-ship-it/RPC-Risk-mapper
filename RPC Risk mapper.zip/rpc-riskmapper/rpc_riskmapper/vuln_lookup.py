"""
vuln_lookup.py - Vulnerability lookup and CVE/CVSS retrieval.
Uses a comprehensive local CVE database with optional NVD API enrichment.
"""

import json
import os
import time
import logging
import hashlib
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from pathlib import Path

logger = logging.getLogger(__name__)

CACHE_DIR = Path.home() / ".rpc_riskmapper" / "cache"
CACHE_TTL = 86400  # 24 hours


@dataclass
class CVSSVector:
    """CVSS v3.x vector breakdown."""
    attack_vector: str = ""        # AV: Network/Adjacent/Local/Physical
    attack_complexity: str = ""    # AC: Low/High
    privileges_required: str = ""  # PR: None/Low/High
    user_interaction: str = ""     # UI: None/Required
    scope: str = ""                # S: Unchanged/Changed
    confidentiality: str = ""      # C: None/Low/High
    integrity: str = ""            # I: None/Low/High
    availability: str = ""         # A: None/Low/High
    vector_string: str = ""

    def to_dict(self) -> Dict[str, str]:
        return asdict(self)


@dataclass
class Vulnerability:
    """Represents a single vulnerability/CVE."""
    cve_id: str
    title: str
    description: str
    cvss_score: float
    cvss_version: str
    severity: str
    cvss_vector: CVSSVector
    affected_service: str
    references: List[str] = field(default_factory=list)
    mitre_techniques: List[str] = field(default_factory=list)
    published_date: str = ""
    patch_available: bool = True
    exploit_available: bool = False
    microsoft_kb: str = ""
    inferred: bool = False   # True if service was inferred from ports, not directly confirmed

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d


def classify_severity(score: float) -> str:
    if score >= 9.0:
        return "Critical"
    elif score >= 7.0:
        return "High"
    elif score >= 4.0:
        return "Medium"
    elif score > 0:
        return "Low"
    return "Informational"


def parse_cvss_vector(vector_string: str) -> CVSSVector:
    """Parse a CVSS v3.x vector string into components."""
    mapping = {
        "AV": {"N": "Network", "A": "Adjacent", "L": "Local", "P": "Physical"},
        "AC": {"L": "Low", "H": "High"},
        "PR": {"N": "None", "L": "Low", "H": "High"},
        "UI": {"N": "None", "R": "Required"},
        "S": {"U": "Unchanged", "C": "Changed"},
        "C": {"N": "None", "L": "Low", "H": "High"},
        "I": {"N": "None", "L": "Low", "H": "High"},
        "A": {"N": "None", "L": "Low", "H": "High"},
    }
    fields = {}
    for part in vector_string.split("/"):
        if ":" in part:
            key, val = part.split(":", 1)
            key = key.strip()
            val = val.strip()
            if key in mapping:
                fields[key] = mapping[key].get(val, val)

    return CVSSVector(
        attack_vector=fields.get("AV", ""),
        attack_complexity=fields.get("AC", ""),
        privileges_required=fields.get("PR", ""),
        user_interaction=fields.get("UI", ""),
        scope=fields.get("S", ""),
        confidentiality=fields.get("C", ""),
        integrity=fields.get("I", ""),
        availability=fields.get("A", ""),
        vector_string=vector_string,
    )


# ──────────────────────────────────────────────────────────────────────
# Comprehensive local CVE database for RPC services
# ──────────────────────────────────────────────────────────────────────
LOCAL_CVE_DB: Dict[str, List[Dict[str, Any]]] = {
    "samr": [
        {
            "cve_id": "CVE-2021-36942",
            "title": "Windows LSA Spoofing (PetitPotam)",
            "description": "An attacker can coerce authentication via LSARPC/SAMR to relay NTLM credentials, enabling domain compromise.",
            "cvss_score": 7.5,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
            "mitre": ["T1557.001", "T1187"],
            "references": ["https://msrc.microsoft.com/update-guide/vulnerability/CVE-2021-36942"],
            "exploit_available": True,
            "kb": "KB5005413",
        },
        {
            "cve_id": "CVE-2022-26923",
            "title": "Active Directory Domain Services Elevation of Privilege (Certifried)",
            "description": "Authenticated user can manipulate machine account attributes to acquire a certificate for domain admin privileges.",
            "cvss_score": 8.8,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1068", "T1558.004"],
            "references": ["https://msrc.microsoft.com/update-guide/vulnerability/CVE-2022-26923"],
            "exploit_available": True,
            "kb": "KB5014754",
        },
        {
            "cve_id": "CVE-2021-42278",
            "title": "SAM Account Name Spoofing (noPac/SamAccountName)",
            "description": "Allows an attacker to impersonate a domain controller via SAM name spoofing, leading to full domain compromise.",
            "cvss_score": 8.8,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1078.002", "T1558.003"],
            "references": ["https://msrc.microsoft.com/update-guide/vulnerability/CVE-2021-42278"],
            "exploit_available": True,
            "kb": "KB5008102",
        },
    ],
    "lsarpc": [
        {
            "cve_id": "CVE-2021-36942",
            "title": "PetitPotam NTLM Relay via LSARPC",
            "description": "LSARPC EfsRpcOpenFileRaw can be abused to coerce NTLM authentication from a domain controller.",
            "cvss_score": 7.5,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
            "mitre": ["T1557.001", "T1187"],
            "exploit_available": True,
            "kb": "KB5005413",
        },
        {
            "cve_id": "CVE-2022-26925",
            "title": "Windows LSA Spoofing Vulnerability",
            "description": "Unauthenticated attacker can coerce domain controller to authenticate via NTLM, enabling relay attacks.",
            "cvss_score": 8.1,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1557.001"],
            "exploit_available": True,
            "kb": "KB5014692",
        },
    ],
    "netlogon": [
        {
            "cve_id": "CVE-2020-1472",
            "title": "Zerologon - Netlogon Elevation of Privilege",
            "description": "Critical flaw in Netlogon AES-CFB8 implementation allows unauthenticated attacker to compromise domain controller by setting computer password to null.",
            "cvss_score": 10.0,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H",
            "mitre": ["T1068", "T1210"],
            "exploit_available": True,
            "kb": "KB4571694",
        },
    ],
    "spoolss": [
        {
            "cve_id": "CVE-2021-34527",
            "title": "PrintNightmare - Windows Print Spooler RCE",
            "description": "Remote code execution via the Print Spooler service. Allows any authenticated user to execute code as SYSTEM on domain controllers.",
            "cvss_score": 8.8,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1210", "T1569.002"],
            "exploit_available": True,
            "kb": "KB5004945",
        },
        {
            "cve_id": "CVE-2021-1675",
            "title": "PrintNightmare Variant - Print Spooler EoP",
            "description": "Elevation of privilege through the Windows Print Spooler service, allowing local attackers to run code as SYSTEM.",
            "cvss_score": 8.8,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1068"],
            "exploit_available": True,
            "kb": "KB5003690",
        },
        {
            "cve_id": "CVE-2022-21999",
            "title": "Windows Print Spooler Elevation of Privilege",
            "description": "Allows authenticated attacker to exploit the print spooler service for local privilege escalation.",
            "cvss_score": 7.8,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1068"],
            "exploit_available": True,
            "kb": "KB5010386",
        },
    ],
    "winspool": [
        {
            "cve_id": "CVE-2021-34527",
            "title": "PrintNightmare - Windows Print Spooler RCE",
            "description": "Remote code execution via the Print Spooler service.",
            "cvss_score": 8.8,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1210", "T1569.002"],
            "exploit_available": True,
            "kb": "KB5004945",
        },
    ],
    "svcctl": [
        {
            "cve_id": "CVE-2022-30206",
            "title": "Windows Print Spooler Elevation of Privilege via SCM",
            "description": "Service Control Manager can be abused by authenticated attackers for privilege escalation through service manipulation.",
            "cvss_score": 7.8,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1543.003", "T1569.002"],
            "exploit_available": False,
            "kb": "KB5015807",
        },
        {
            "cve_id": "CVE-2021-36934",
            "title": "HiveNightmare / SeriousSAM",
            "description": "Overly permissive ACLs on SAM/SYSTEM/SECURITY hive shadow copies allow any user to read credentials.",
            "cvss_score": 7.8,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1003.002"],
            "exploit_available": True,
            "kb": "KB5004945",
        },
    ],
    "winreg": [
        {
            "cve_id": "CVE-2022-35770",
            "title": "Windows NTLM Spoofing via Remote Registry",
            "description": "Remote Registry service can be exploited for NTLM relay attacks.",
            "cvss_score": 6.5,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N",
            "mitre": ["T1012", "T1557.001"],
            "exploit_available": False,
            "kb": "KB5018410",
        },
    ],
    "srvsvc": [
        {
            "cve_id": "CVE-2017-0143",
            "title": "EternalBlue - Windows SMB Remote Code Execution",
            "description": "Critical SMBv1 vulnerability exploited by WannaCry and NotPetya. Allows unauthenticated remote code execution.",
            "cvss_score": 8.1,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1210", "T1570"],
            "exploit_available": True,
            "kb": "MS17-010",
        },
        {
            "cve_id": "CVE-2020-0796",
            "title": "SMBGhost - Windows SMBv3 RCE",
            "description": "Integer overflow in SMBv3 compression allows unauthenticated remote code execution.",
            "cvss_score": 10.0,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H",
            "mitre": ["T1210"],
            "exploit_available": True,
            "kb": "KB4551762",
        },
    ],
    "epmapper": [
        {
            "cve_id": "CVE-2003-0352",
            "title": "MS03-026 DCOM RPC Buffer Overflow (Blaster Worm)",
            "description": "Classic buffer overflow in DCOM RPC interface. Historic but may still be present on unpatched legacy systems.",
            "cvss_score": 7.5,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:H",
            "mitre": ["T1210"],
            "exploit_available": True,
            "kb": "MS03-026",
        },
    ],
    "drsuapi": [
        {
            "cve_id": "CVE-2022-26923",
            "title": "Certifried - AD CS Privilege Escalation",
            "description": "Allows DCSync-capable attackers to obtain certificates for domain admin via DRS replication abuse.",
            "cvss_score": 8.8,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1003.006", "T1558.004"],
            "exploit_available": True,
            "kb": "KB5014754",
        },
    ],
    "atsvc": [
        {
            "cve_id": "CVE-2019-0708",
            "title": "BlueKeep - RDP Remote Code Execution",
            "description": "While primarily an RDP vulnerability, Task Scheduler exposure indicates broader attack surface on the host.",
            "cvss_score": 9.8,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1210"],
            "exploit_available": True,
            "kb": "KB4499175",
        },
    ],
    "efsr": [
        {
            "cve_id": "CVE-2021-36942",
            "title": "PetitPotam - EFS RPC Coerced Authentication",
            "description": "EFS RPC functions (EfsRpcOpenFileRaw, EfsRpcEncryptFileSrv) can coerce NTLM authentication from domain controllers.",
            "cvss_score": 7.5,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
            "mitre": ["T1557.001", "T1187"],
            "exploit_available": True,
            "kb": "KB5005413",
        },
    ],
    "dfsnm": [
        {
            "cve_id": "CVE-2022-26925",
            "title": "DFSCoerce - NTLM Relay via DFS",
            "description": "DFS Namespace management RPC interface can be abused for NTLM authentication coercion similar to PetitPotam.",
            "cvss_score": 8.1,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1557.001"],
            "exploit_available": True,
            "kb": "KB5014692",
        },
    ],
    "wkssvc": [
        {
            "cve_id": "CVE-2022-38023",
            "title": "Netlogon RPC Elevation of Privilege",
            "description": "Workstation service exposure combined with weak Netlogon encryption allows relay attacks.",
            "cvss_score": 8.1,
            "cvss_version": "3.1",
            "vector": "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:H/A:H",
            "mitre": ["T1557.001"],
            "exploit_available": False,
            "kb": "KB5021130",
        },
    ],
}


class VulnerabilityLookup:
    """Look up vulnerabilities for RPC services using local DB + optional NVD API."""

    def __init__(self, nvd_api_key: Optional[str] = None,
                 use_nvd: bool = False,
                 custom_db_path: Optional[str] = None):
        self.nvd_api_key = nvd_api_key
        self.use_nvd = use_nvd
        self.custom_db = self._load_custom_db(custom_db_path) if custom_db_path else {}
        CACHE_DIR.mkdir(parents=True, exist_ok=True)

    def _load_custom_db(self, path: str) -> Dict:
        """Load a custom CVE database from JSON file."""
        try:
            with open(path, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Could not load custom DB from {path}: {e}")
            return {}

    def lookup(self, services: List[str], confirmed_only: bool = False) -> List[Vulnerability]:
        """
        Look up vulnerabilities for a list of RPC service names.

        Args:
            services: List of service names (e.g., ["samr", "spoolss"])
            confirmed_only: If False (default), services were inferred from ports;
                            if True, they were directly confirmed via RPC enumeration.

        Returns:
            Deduplicated list of Vulnerability objects
        """
        seen_cves = set()
        vulns = []

        for service in services:
            svc_lower = service.lower().strip()

            # Check local database
            entries = LOCAL_CVE_DB.get(svc_lower, [])

            # Check custom database
            if svc_lower in self.custom_db:
                entries.extend(self.custom_db[svc_lower])

            for entry in entries:
                cve_id = entry["cve_id"]
                if cve_id in seen_cves:
                    continue
                seen_cves.add(cve_id)

                vector = parse_cvss_vector(entry.get("vector", ""))
                score = entry["cvss_score"]

                vuln = Vulnerability(
                    cve_id=cve_id,
                    title=entry["title"],
                    description=entry["description"],
                    cvss_score=score,
                    cvss_version=entry.get("cvss_version", "3.1"),
                    severity=classify_severity(score),
                    cvss_vector=vector,
                    affected_service=svc_lower,
                    references=entry.get("references", []),
                    mitre_techniques=entry.get("mitre", []),
                    exploit_available=entry.get("exploit_available", False),
                    microsoft_kb=entry.get("kb", ""),
                    patch_available=True,
                    inferred=not confirmed_only,
                )
                vulns.append(vuln)

            # Optional NVD enrichment
            if self.use_nvd:
                nvd_vulns = self._query_nvd(svc_lower, seen_cves)
                vulns.extend(nvd_vulns)

        # Sort by CVSS score descending
        vulns.sort(key=lambda v: v.cvss_score, reverse=True)
        return vulns

    def _query_nvd(self, service: str, seen: set) -> List[Vulnerability]:
        """Query NVD API for additional CVEs related to a service."""
        try:
            import requests
        except ImportError:
            logger.warning("requests library not installed, skipping NVD lookup")
            return []

        cache_key = hashlib.md5(f"nvd_{service}".encode()).hexdigest()
        cache_file = CACHE_DIR / f"{cache_key}.json"

        # Check cache
        if cache_file.exists():
            mod_time = cache_file.stat().st_mtime
            if time.time() - mod_time < CACHE_TTL:
                try:
                    with open(cache_file) as f:
                        cached = json.load(f)
                    return [self._dict_to_vuln(d, service) for d in cached
                            if d["cve_id"] not in seen]
                except Exception:
                    pass

        keyword_map = {
            "samr": "Windows SAM Remote Protocol",
            "lsarpc": "Windows LSA Remote Protocol",
            "netlogon": "Windows Netlogon",
            "spoolss": "Windows Print Spooler",
            "svcctl": "Windows Service Control Manager",
            "srvsvc": "Windows Server Service SMB",
            "drsuapi": "Active Directory Replication",
            "efsr": "Windows Encrypting File System",
        }
        keyword = keyword_map.get(service, f"Windows RPC {service}")

        url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
        params = {
            "keywordSearch": keyword,
            "cvssV3Severity": "HIGH",
            "resultsPerPage": 10,
        }
        headers = {}
        if self.nvd_api_key:
            headers["apiKey"] = self.nvd_api_key

        try:
            resp = requests.get(url, params=params, headers=headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()

            vulns = []
            cache_data = []

            for item in data.get("vulnerabilities", []):
                cve = item.get("cve", {})
                cve_id = cve.get("id", "")
                if cve_id in seen:
                    continue
                seen.add(cve_id)

                # Extract CVSS v3.x
                metrics = cve.get("metrics", {})
                cvss_data = {}
                for key in ["cvssMetricV31", "cvssMetricV30"]:
                    if key in metrics and metrics[key]:
                        cvss_data = metrics[key][0].get("cvssData", {})
                        break

                score = cvss_data.get("baseScore", 0.0)
                vector_str = cvss_data.get("vectorString", "")

                desc_list = cve.get("descriptions", [])
                desc = next((d["value"] for d in desc_list if d["lang"] == "en"), "")

                vuln_dict = {
                    "cve_id": cve_id,
                    "title": cve_id,
                    "description": desc[:300],
                    "cvss_score": score,
                    "cvss_version": "3.1",
                    "vector": vector_str,
                    "service": service,
                }
                cache_data.append(vuln_dict)
                vulns.append(self._dict_to_vuln(vuln_dict, service))

            # Save cache
            with open(cache_file, "w") as f:
                json.dump(cache_data, f)

            return vulns

        except Exception as e:
            logger.warning(f"NVD query failed for {service}: {e}")
            return []

    def _dict_to_vuln(self, d: Dict, service: str) -> Vulnerability:
        vector = parse_cvss_vector(d.get("vector", ""))
        score = d["cvss_score"]
        return Vulnerability(
            cve_id=d["cve_id"],
            title=d.get("title", d["cve_id"]),
            description=d.get("description", ""),
            cvss_score=score,
            cvss_version=d.get("cvss_version", "3.1"),
            severity=classify_severity(score),
            cvss_vector=vector,
            affected_service=service,
            references=d.get("references", []),
            mitre_techniques=d.get("mitre", []),
        )

    def get_stats(self) -> Dict[str, int]:
        """Get statistics about the local CVE database."""
        total = 0
        services = 0
        for svc, cves in LOCAL_CVE_DB.items():
            services += 1
            total += len(cves)
        return {
            "total_cves": total,
            "services_covered": services,
            "custom_db_loaded": bool(self.custom_db),
            "nvd_enabled": self.use_nvd,
        }
