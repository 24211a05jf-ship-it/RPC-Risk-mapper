"""
analyzer.py - CVSS-based risk analysis engine.
Aggregates vulnerability data and computes risk scores.
"""

import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field, asdict

logger = logging.getLogger(__name__)


# MITRE ATT&CK technique descriptions
MITRE_TECHNIQUES = {
    "T1003.002": "OS Credential Dumping: Security Account Manager",
    "T1003.006": "OS Credential Dumping: DCSync",
    "T1012": "Query Registry",
    "T1068": "Exploitation for Privilege Escalation",
    "T1078.002": "Valid Accounts: Domain Accounts",
    "T1187": "Forced Authentication",
    "T1210": "Exploitation of Remote Services",
    "T1543.003": "Create or Modify System Process: Windows Service",
    "T1557.001": "Adversary-in-the-Middle: LLMNR/NBT-NS Poisoning and SMB Relay",
    "T1558.003": "Steal or Forge Kerberos Tickets: Kerberoasting",
    "T1558.004": "Steal or Forge Kerberos Tickets: AS-REP Roasting",
    "T1569.002": "System Services: Service Execution",
    "T1570": "Lateral Tool Transfer",
}


@dataclass
class RiskSummary:
    """Aggregated risk analysis results."""
    target: str
    total_vulnerabilities: int
    unique_cves: int
    average_cvss: float
    highest_cvss: float
    highest_cve: str
    weighted_risk_score: float
    overall_risk_level: str
    severity_distribution: Dict[str, int]
    affected_services: List[str]
    exploitable_count: int
    mitre_techniques: Dict[str, str]
    critical_findings: List[str]
    risk_factors: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class RiskAnalyzer:
    """Analyze and aggregate vulnerability data for risk assessment."""

    # Weights for risk score calculation
    SEVERITY_WEIGHTS = {
        "Critical": 4.0,
        "High": 3.0,
        "Medium": 2.0,
        "Low": 1.0,
        "Informational": 0.0,
    }

    def analyze(self, target: str, vulnerabilities: list,
                scan_result: Optional[Any] = None,
                rpc_result: Optional[Any] = None) -> RiskSummary:
        """
        Perform comprehensive risk analysis.

        Args:
            target: Target IP/hostname
            vulnerabilities: List of Vulnerability objects
            scan_result: Optional ScanResult for additional context
            rpc_result: Optional RPCEnumResult for additional context
        """
        if not vulnerabilities:
            return RiskSummary(
                target=target,
                total_vulnerabilities=0,
                unique_cves=0,
                average_cvss=0.0,
                highest_cvss=0.0,
                highest_cve="N/A",
                weighted_risk_score=0.0,
                overall_risk_level="Informational",
                severity_distribution={"Critical": 0, "High": 0, "Medium": 0, "Low": 0},
                affected_services=[],
                exploitable_count=0,
                mitre_techniques={},
                critical_findings=["No known vulnerabilities found for discovered services."],
                risk_factors=[],
            )

        # Deduplicate CVEs
        seen = set()
        unique_vulns = []
        for v in vulnerabilities:
            if v.cve_id not in seen:
                seen.add(v.cve_id)
                unique_vulns.append(v)

        # CVSS statistics
        scores = [v.cvss_score for v in unique_vulns]
        avg_cvss = sum(scores) / len(scores)
        max_cvss = max(scores)
        max_cve = next(v.cve_id for v in unique_vulns if v.cvss_score == max_cvss)

        # Severity distribution
        severity_dist = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
        for v in unique_vulns:
            sev = v.severity
            if sev in severity_dist:
                severity_dist[sev] += 1

        # Affected services
        affected = sorted(set(v.affected_service for v in unique_vulns if v.affected_service))

        # Exploitable count
        exploitable = sum(1 for v in unique_vulns if v.exploit_available)

        # MITRE ATT&CK mapping
        mitre = {}
        for v in unique_vulns:
            for tech in v.mitre_techniques:
                if tech not in mitre:
                    mitre[tech] = MITRE_TECHNIQUES.get(tech, tech)

        # Weighted risk score (0-100)
        weighted = self._calculate_weighted_score(unique_vulns, scan_result)

        # Overall risk level
        risk_level = self._classify_overall_risk(weighted, severity_dist, exploitable)

        # Critical findings
        findings = self._generate_critical_findings(unique_vulns, scan_result, rpc_result)

        # Risk factors
        factors = self._identify_risk_factors(unique_vulns, scan_result, rpc_result)

        # If services were inferred (not confirmed), apply a confidence penalty
        inferred = rpc_result.inferred if (rpc_result and hasattr(rpc_result, "inferred")) else False
        if inferred:
            # Cap score to 85 max and note uncertainty
            weighted = min(weighted, 85.0)
            factors.append("Services inferred from port scan only — actual exposure may vary")

        return RiskSummary(
            target=target,
            total_vulnerabilities=len(vulnerabilities),
            unique_cves=len(unique_vulns),
            average_cvss=round(avg_cvss, 1),
            highest_cvss=max_cvss,
            highest_cve=max_cve,
            weighted_risk_score=round(weighted, 1),
            overall_risk_level=risk_level,
            severity_distribution=severity_dist,
            affected_services=affected,
            exploitable_count=exploitable,
            mitre_techniques=mitre,
            critical_findings=findings,
            risk_factors=factors,
        )

    def _calculate_weighted_score(self, vulns: list,
                                  scan_result: Optional[Any]) -> float:
        """Calculate a weighted risk score from 0-100."""
        if not vulns:
            return 0.0

        # Base: weighted average of CVSS scores
        total_weight = 0
        weighted_sum = 0
        for v in vulns:
            weight = self.SEVERITY_WEIGHTS.get(v.severity, 1.0)
            if v.exploit_available:
                weight *= 1.5  # Boost for exploitable vulns
            weighted_sum += v.cvss_score * weight
            total_weight += weight

        base_score = (weighted_sum / total_weight) if total_weight > 0 else 0

        # Normalize to 0-100 scale
        score = (base_score / 10.0) * 100

        # Adjust for volume
        vuln_count_factor = min(len(vulns) / 5.0, 1.5)  # Cap at 1.5x
        score *= min(vuln_count_factor, 1.0)
        score += (vuln_count_factor - 1.0) * 10 if vuln_count_factor > 1.0 else 0

        # Adjust for exploitability
        exploit_ratio = sum(1 for v in vulns if v.exploit_available) / len(vulns)
        score += exploit_ratio * 10

        return min(score, 100.0)

    def _classify_overall_risk(self, weighted_score: float,
                               severity_dist: Dict[str, int],
                               exploitable: int) -> str:
        """Determine overall risk classification."""
        if severity_dist.get("Critical", 0) > 0 or weighted_score >= 90:
            return "CRITICAL"
        if severity_dist.get("High", 0) >= 2 or weighted_score >= 70:
            return "HIGH"
        if severity_dist.get("High", 0) >= 1 or weighted_score >= 50:
            return "MEDIUM-HIGH"
        if severity_dist.get("Medium", 0) >= 1 or weighted_score >= 30:
            return "MEDIUM"
        if weighted_score >= 10:
            return "LOW"
        return "INFORMATIONAL"

    def _generate_critical_findings(self, vulns: list,
                                    scan_result: Optional[Any],
                                    rpc_result: Optional[Any]) -> List[str]:
        """Generate list of critical findings."""
        findings = []

        # Check for critical CVEs
        critical = [v for v in vulns if v.severity == "Critical"]
        for v in critical:
            findings.append(
                f"CRITICAL: {v.cve_id} ({v.title}) - CVSS {v.cvss_score}"
                f"{' [EXPLOIT AVAILABLE]' if v.exploit_available else ''}"
            )

        # Check for high-impact patterns
        cve_ids = {v.cve_id for v in vulns}
        if "CVE-2020-1472" in cve_ids:
            findings.append(
                "⚠ Zerologon detected - Domain controller is at immediate risk of full compromise"
            )
        if "CVE-2021-34527" in cve_ids:
            findings.append(
                "⚠ PrintNightmare detected - Remote code execution as SYSTEM is possible"
            )
        if "CVE-2020-0796" in cve_ids:
            findings.append(
                "⚠ SMBGhost detected - Wormable remote code execution vulnerability"
            )

        # RPC-specific findings
        if scan_result and hasattr(scan_result, 'has_rpc') and scan_result.has_rpc():
            findings.append("Port 135 (RPC Endpoint Mapper) is exposed to the network")

        exploitable = [v for v in vulns if v.exploit_available]
        if exploitable:
            findings.append(
                f"{len(exploitable)} vulnerabilities have known public exploits"
            )

        return findings or ["No critical findings."]

    def _identify_risk_factors(self, vulns: list,
                               scan_result: Optional[Any],
                               rpc_result: Optional[Any]) -> List[str]:
        """Identify environmental risk factors."""
        factors = []

        services = set(v.affected_service for v in vulns)

        if "netlogon" in services:
            factors.append("Netlogon service exposed - domain controller risk")
        if "drsuapi" in services:
            factors.append("Directory Replication service exposed - DCSync attack surface")
        if "spoolss" in services or "winspool" in services:
            factors.append("Print Spooler running - common attack vector for RCE")
        if "efsr" in services:
            factors.append("EFS RPC exposed - NTLM relay coercion possible")
        if "winreg" in services:
            factors.append("Remote Registry accessible - information disclosure risk")
        if any(v.exploit_available for v in vulns):
            factors.append("Public exploits available - immediate exploitation risk")
        if scan_result and hasattr(scan_result, 'get_open_ports'):
            open_count = len(scan_result.get_open_ports())
            if open_count > 5:
                factors.append(f"{open_count} open ports detected - large attack surface")

        return factors
