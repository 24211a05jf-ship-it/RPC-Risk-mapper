"""
reporter.py - Report generation module.
Generates console, JSON, and HTML reports.
"""

import json
import os
import html as html_lib
from datetime import datetime
from typing import List, Optional, Any


class ConsoleReporter:
    """Generate colored console output."""

    COLORS = {
        "RED": "\033[91m",
        "YELLOW": "\033[93m",
        "GREEN": "\033[92m",
        "CYAN": "\033[96m",
        "WHITE": "\033[97m",
        "BOLD": "\033[1m",
        "DIM": "\033[2m",
        "RESET": "\033[0m",
        "BG_RED": "\033[41m",
        "BG_YELLOW": "\033[43m",
        "BG_GREEN": "\033[42m",
        "MAGENTA": "\033[95m",
    }

    SEVERITY_COLORS = {
        "Critical": "RED",
        "High": "YELLOW",
        "Medium": "CYAN",
        "Low": "GREEN",
        "Informational": "DIM",
    }

    RISK_COLORS = {
        "CRITICAL": "BG_RED",
        "HIGH": "RED",
        "MEDIUM-HIGH": "YELLOW",
        "MEDIUM": "YELLOW",
        "LOW": "GREEN",
        "INFORMATIONAL": "DIM",
    }

    def __init__(self, no_color: bool = False):
        self.no_color = no_color

    def _c(self, color: str, text: str) -> str:
        if self.no_color:
            return text
        code = self.COLORS.get(color, "")
        return f"{code}{text}{self.COLORS['RESET']}"

    def print_banner(self):
        banner = r"""
  ____  ____   ____   ____  _     _    __  __
 |  _ \|  _ \ / ___| |  _ \(_)___| | _|  \/  | __ _ _ __  _ __   ___ _ __
 | |_) | |_) | |     | |_) | / __| |/ / |\/| |/ _` | '_ \| '_ \ / _ \ '__|
 |  _ <|  __/| |___  |  _ <| \__ \   <| |  | | (_| | |_) | |_) |  __/ |
 |_| \_\_|    \____| |_| \_\_|___/_|\_\_|  |_|\__,_| .__/| .__/ \___|_|
                                                    |_|   |_|
        """
        print(self._c("CYAN", banner))
        print(self._c("BOLD", "  RPC RiskMapper v1.0.0 - RPC Network Risk Assessment Tool"))
        print(self._c("DIM", f"  Scan started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"))
        print()

    def print_scan_results(self, scan_result):
        print(self._c("BOLD", "=" * 70))
        print(self._c("BOLD", "  SCAN RESULTS"))
        print(self._c("BOLD", "=" * 70))
        print(f"  Target:    {self._c('WHITE', scan_result.target)}")
        print(f"  IP:        {scan_result.ip_address}")
        if scan_result.hostname:
            print(f"  Hostname:  {scan_result.hostname}")
        if scan_result.os_guess:
            print(f"  OS:        {scan_result.os_guess}")
        print()

        open_ports = scan_result.get_open_ports()
        if open_ports:
            print(self._c("BOLD", "  Open Ports:"))
            print(f"  {'Port':<10} {'Service':<15} {'Product':<25} {'Version'}")
            print(f"  {'-'*10} {'-'*15} {'-'*25} {'-'*15}")
            for p in open_ports:
                port_str = f"{p.port}/{p.protocol}"
                color = "RED" if p.port == 135 else "YELLOW"
                colored_port = self._c(color, port_str)
                pad = max(0, 10 - len(port_str))
                print(f"  {colored_port}{chr(32) * pad} {p.service:<15} {p.product:<25} {p.version}")
        else:
            print(self._c("GREEN", "  No open RPC ports found."))
        print()

    def print_rpc_results(self, rpc_result):
        print(self._c("BOLD", "=" * 70))
        print(self._c("BOLD", "  RPC ENDPOINT ENUMERATION"))
        print(self._c("BOLD", "=" * 70))
        print(f"  Method:    {rpc_result.method}")
        print(f"  Endpoints: {len(rpc_result.endpoints)}")
        print(f"  Services:  {', '.join(rpc_result.services) if rpc_result.services else 'None'}")
        print()

        if rpc_result.endpoints:
            print(f"  {'Service':<15} {'UUID':<40} {'Protocol'}")
            print(f"  {'-'*15} {'-'*40} {'-'*15}")
            shown = set()
            for ep in rpc_result.endpoints:
                key = f"{ep.service_name}_{ep.uuid}"
                if key in shown:
                    continue
                shown.add(key)
                svc = ep.service_name or "unknown"
                print(f"  {self._c('YELLOW', svc):<27} {ep.uuid:<40} {ep.protocol}")
        print()

    def print_vulnerabilities(self, vulns, inferred: bool = False):
        print(self._c("BOLD", "=" * 70))
        print(self._c("BOLD", "  VULNERABILITY FINDINGS"))
        print(self._c("BOLD", "=" * 70))

        if inferred:
            print(self._c("YELLOW",
                "  ⚠  NOTE: RPC services were INFERRED from open ports — not confirmed via"
                "\n     Impacket. Results show potential exposure only. Run with Impacket"
                "\n     installed for confirmed service listings.\n"))

        if not vulns:
            print(self._c("GREEN", "  No known vulnerabilities found."))
            print()
            return

        seen = set()
        for v in vulns:
            if v.cve_id in seen:
                continue
            seen.add(v.cve_id)

            sev_color = self.SEVERITY_COLORS.get(v.severity, "WHITE")
            print(f"\n  {self._c('BOLD', v.cve_id)}  {self._c(sev_color, f'[{v.severity.upper()}]')}")
            print(f"  Title:     {v.title}")
            print(f"  CVSS:      {self._c(sev_color, str(v.cvss_score))} / 10.0 (v{v.cvss_version})")
            print(f"  Service:   {v.affected_service}")

            if v.cvss_vector.vector_string:
                vec = v.cvss_vector
                print(f"  Vector:    AV:{vec.attack_vector} AC:{vec.attack_complexity} "
                      f"PR:{vec.privileges_required} UI:{vec.user_interaction}")
                print(f"             S:{vec.scope} C:{vec.confidentiality} "
                      f"I:{vec.integrity} A:{vec.availability}")

            if v.exploit_available:
                print(f"  Exploit:   {self._c('RED', '⚠ PUBLIC EXPLOIT AVAILABLE')}")
            if v.microsoft_kb:
                print(f"  Patch:     {v.microsoft_kb}")
            if v.mitre_techniques:
                print(f"  MITRE:     {', '.join(v.mitre_techniques)}")

            # Truncated description
            desc = v.description[:120] + "..." if len(v.description) > 120 else v.description
            print(f"  Details:   {self._c('DIM', desc)}")

        print()

    def print_risk_summary(self, summary, inferred: bool = False):
        print(self._c("BOLD", "=" * 70))
        print(self._c("BOLD", "  RISK ASSESSMENT SUMMARY"))
        print(self._c("BOLD", "=" * 70))

        risk_color = self.RISK_COLORS.get(summary.overall_risk_level, "WHITE")
        print(f"\n  Overall Risk Level: {self._c(risk_color, f' {summary.overall_risk_level} ')}")
        if inferred:
            print(self._c("YELLOW",
                "  ⚠  Risk based on INFERRED services (port scan only).\n"
                "     Actual exposure may be lower if some services are not running."))
        print(f"  Weighted Risk Score: {summary.weighted_risk_score}/100")
        print()
        print(f"  Total Vulnerabilities:  {summary.total_vulnerabilities}")
        print(f"  Unique CVEs:            {summary.unique_cves}")
        print(f"  Average CVSS:           {summary.average_cvss}")
        print(f"  Highest CVSS:           {self._c('RED', str(summary.highest_cvss))} ({summary.highest_cve})")
        print(f"  Exploitable:            {self._c('RED' if summary.exploitable_count else 'GREEN', str(summary.exploitable_count))}")
        print()

        print("  Severity Distribution:")
        for sev, count in summary.severity_distribution.items():
            bar = "█" * count + "░" * (10 - count)
            color = self.SEVERITY_COLORS.get(sev, "WHITE")
            print(f"    {sev:<12} {self._c(color, bar)} {count}")
        print()

        if summary.critical_findings:
            print(self._c("BOLD", "  Critical Findings:"))
            for finding in summary.critical_findings:
                print(f"    • {self._c('RED', finding)}")
            print()

        if summary.risk_factors:
            print(self._c("BOLD", "  Risk Factors:"))
            for factor in summary.risk_factors:
                print(f"    • {factor}")
            print()

        if summary.mitre_techniques:
            print(self._c("BOLD", "  MITRE ATT&CK Techniques:"))
            for tech_id, tech_name in summary.mitre_techniques.items():
                print(f"    {self._c('MAGENTA', tech_id)}: {tech_name}")
            print()

    def print_recommendations(self, recommendations, executive_summary: str = ""):
        print(self._c("BOLD", "=" * 70))
        print(self._c("BOLD", "  RECOMMENDATIONS"))
        print(self._c("BOLD", "=" * 70))

        if executive_summary:
            print(f"\n  {self._c('BOLD', 'Executive Summary:')}")
            # Word wrap
            words = executive_summary.split()
            line = "  "
            for w in words:
                if len(line) + len(w) > 68:
                    print(line)
                    line = "  " + w + " "
                else:
                    line += w + " "
            if line.strip():
                print(line)
            print()

        for rec in recommendations:
            sev_color = self.SEVERITY_COLORS.get(rec.severity, "WHITE")
            cat_icon = {"Patch": "🔧", "Config": "⚙", "Network": "🛡", "Monitor": "👁"}.get(rec.category, "📋")
            print(f"\n  {cat_icon} [{self._c(sev_color, rec.severity.upper())}] {self._c('BOLD', rec.title)}")
            print(f"     Category: {rec.category} | Effort: {rec.effort} | Impact: {rec.impact}")

            # Word wrap description
            words = rec.description.split()
            line = "     "
            for w in words:
                if len(line) + len(w) > 68:
                    print(line)
                    line = "     " + w + " "
                else:
                    line += w + " "
            if line.strip():
                print(line)

            if rec.affected_cves:
                print(f"     CVEs: {', '.join(rec.affected_cves)}")

        print()
        print(self._c("BOLD", "=" * 70))
        print(self._c("DIM", f"  Report generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"))
        print(self._c("BOLD", "=" * 70))


class JSONReporter:
    """Export results as JSON."""

    def export(self, filepath: str, target: str,
               scan_result, rpc_result, vulns, risk_summary,
               recommendations, executive_summary: str = ""):
        report = {
            "tool": "RPC RiskMapper",
            "version": "1.0.0",
            "generated": datetime.now().isoformat(),
            "target": target,
            "scan": scan_result.to_dict() if scan_result else None,
            "rpc_enumeration": rpc_result.to_dict() if rpc_result else None,
            "vulnerabilities": [v.to_dict() for v in vulns],
            "risk_summary": risk_summary.to_dict(),
            "recommendations": [r.to_dict() for r in recommendations],
            "executive_summary": executive_summary,
        }

        with open(filepath, "w") as f:
            json.dump(report, f, indent=2, default=str)


class HTMLReporter:
    """Export results as HTML report."""

    def export(self, filepath: str, target: str,
               scan_result, rpc_result, vulns, risk_summary,
               recommendations, executive_summary: str = ""):

        sev_colors = {
            "Critical": "#dc2626", "High": "#ea580c",
            "Medium": "#ca8a04", "Low": "#16a34a",
        }
        risk_colors = {
            "CRITICAL": "#dc2626", "HIGH": "#ea580c",
            "MEDIUM-HIGH": "#ca8a04", "MEDIUM": "#eab308",
            "LOW": "#16a34a", "INFORMATIONAL": "#6b7280",
        }

        risk_color = risk_colors.get(risk_summary.overall_risk_level, "#6b7280")

        vulns_html = ""
        seen = set()
        for v in vulns:
            if v.cve_id in seen:
                continue
            seen.add(v.cve_id)
            sc = sev_colors.get(v.severity, "#6b7280")
            exploit_badge = '<span class="badge bg-danger">EXPLOIT AVAILABLE</span>' if v.exploit_available else ''
            vulns_html += f"""
            <div class="vuln-card" style="border-left: 4px solid {sc};">
                <h4>{html_lib.escape(v.cve_id)} <span class="badge" style="background:{sc};color:#fff">{v.severity}</span> {exploit_badge}</h4>
                <p><strong>{html_lib.escape(v.title)}</strong></p>
                <p>CVSS: <strong>{v.cvss_score}</strong>/10.0 | Service: {html_lib.escape(v.affected_service)} | KB: {html_lib.escape(v.microsoft_kb or 'N/A')}</p>
                <p class="desc">{html_lib.escape(v.description[:200])}</p>
                {f'<p>MITRE: {", ".join(v.mitre_techniques)}</p>' if v.mitre_techniques else ''}
            </div>"""

        recs_html = ""
        for r in recommendations:
            sc = sev_colors.get(r.severity, "#6b7280")
            recs_html += f"""
            <div class="rec-card">
                <h4><span class="badge" style="background:{sc};color:#fff">{r.category}</span> {html_lib.escape(r.title)}</h4>
                <p>{html_lib.escape(r.description)}</p>
                <p class="meta">Effort: {r.effort} | Impact: {r.impact} {f'| CVEs: {", ".join(r.affected_cves)}' if r.affected_cves else ''}</p>
            </div>"""

        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>RPC RiskMapper Report - {html_lib.escape(target)}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:'Segoe UI',system-ui,sans-serif;background:#0f172a;color:#e2e8f0;line-height:1.6}}
.container{{max-width:1000px;margin:0 auto;padding:20px}}
h1{{color:#38bdf8;margin-bottom:5px}} h2{{color:#94a3b8;margin:30px 0 15px;border-bottom:1px solid #334155;padding-bottom:8px}}
.risk-banner{{background:{risk_color};color:#fff;padding:20px;border-radius:8px;text-align:center;margin:20px 0;font-size:1.4em;font-weight:bold}}
.stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px;margin:20px 0}}
.stat{{background:#1e293b;padding:15px;border-radius:8px;text-align:center}}
.stat .value{{font-size:2em;font-weight:bold;color:#38bdf8}} .stat .label{{color:#94a3b8;font-size:.85em}}
.vuln-card,.rec-card{{background:#1e293b;padding:15px;margin:10px 0;border-radius:8px}}
.vuln-card h4,.rec-card h4{{margin-bottom:8px}}
.badge{{padding:2px 8px;border-radius:4px;font-size:.8em;font-weight:600}}
.bg-danger{{background:#dc2626;color:#fff}}
.desc{{color:#94a3b8;font-size:.9em}} .meta{{color:#64748b;font-size:.85em}}
.executive{{background:#1e293b;padding:20px;border-radius:8px;border-left:4px solid #38bdf8;margin:20px 0}}
.footer{{text-align:center;color:#475569;margin-top:40px;padding:20px;border-top:1px solid #1e293b}}
</style>
</head>
<body>
<div class="container">
<h1>🛡 RPC RiskMapper Report</h1>
<p style="color:#64748b">Target: {html_lib.escape(target)} | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>

<div class="risk-banner">Overall Risk Level: {risk_summary.overall_risk_level}</div>

{f'<div class="executive"><strong>Executive Summary:</strong><br>{html_lib.escape(executive_summary)}</div>' if executive_summary else ''}

<div class="stats">
<div class="stat"><div class="value">{risk_summary.unique_cves}</div><div class="label">Unique CVEs</div></div>
<div class="stat"><div class="value">{risk_summary.average_cvss}</div><div class="label">Avg CVSS</div></div>
<div class="stat"><div class="value" style="color:{risk_color}">{risk_summary.highest_cvss}</div><div class="label">Highest CVSS</div></div>
<div class="stat"><div class="value">{risk_summary.weighted_risk_score}</div><div class="label">Risk Score /100</div></div>
<div class="stat"><div class="value" style="color:#dc2626">{risk_summary.exploitable_count}</div><div class="label">Exploitable</div></div>
</div>

<h2>Severity Distribution</h2>
<div class="stats">
<div class="stat"><div class="value" style="color:#dc2626">{risk_summary.severity_distribution.get('Critical',0)}</div><div class="label">Critical</div></div>
<div class="stat"><div class="value" style="color:#ea580c">{risk_summary.severity_distribution.get('High',0)}</div><div class="label">High</div></div>
<div class="stat"><div class="value" style="color:#ca8a04">{risk_summary.severity_distribution.get('Medium',0)}</div><div class="label">Medium</div></div>
<div class="stat"><div class="value" style="color:#16a34a">{risk_summary.severity_distribution.get('Low',0)}</div><div class="label">Low</div></div>
</div>

<h2>Vulnerabilities ({risk_summary.unique_cves})</h2>
{vulns_html}

<h2>Recommendations ({len(recommendations)})</h2>
{recs_html}

<div class="footer">RPC RiskMapper v1.0.0 | Professional Network Risk Assessment</div>
</div>
</body>
</html>"""

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html_content)
