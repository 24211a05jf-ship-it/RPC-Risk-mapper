"""
rpc_enum.py - RPC Endpoint Enumeration module.
Uses Impacket rpcdump or raw RPC queries to enumerate endpoints.
Falls back to port-based inference ONLY when the host is reachable
but Impacket is unavailable — never fabricates results for unreachable hosts.
"""

import subprocess
import re
import logging
import shutil
import socket
import struct
from typing import Dict, List, Optional, Any, Set
from dataclasses import dataclass, field, asdict

logger = logging.getLogger(__name__)


@dataclass
class RPCEndpoint:
    uuid: str
    version: str
    protocol: str
    endpoint: str
    service_name: str
    annotation: str = ""
    known_service: str = ""
    confirmed: bool = True      # False = inferred, not directly observed

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RPCEnumResult:
    target: str
    endpoints: List[RPCEndpoint] = field(default_factory=list)
    services: List[str] = field(default_factory=list)
    success: bool = True
    error: str = ""
    method: str = "impacket"
    host_reachable: bool = False   # True only if we got a TCP response
    port_135_open: bool = False
    open_ports: List[int] = field(default_factory=list)
    inferred: bool = False         # True if services were guessed, not confirmed

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# Well-known RPC interface UUIDs mapped to service names
KNOWN_RPC_UUIDS = {
    "12345778-1234-abcd-ef00-0123456789ab": "lsarpc (LSA Remote Protocol)",
    "12345778-1234-abcd-ef00-0123456789ac": "samr (SAM Remote Protocol)",
    "12345678-1234-abcd-ef00-01234567cffb": "netlogon (Netlogon Remote Protocol)",
    "e1af8308-5d1f-11c9-91a4-08002b14a0fa": "epmapper (RPC Endpoint Mapper)",
    "367abb81-9844-35f1-ad32-98f038001003": "svcctl (Service Control Manager)",
    "338cd001-2244-31f1-aaaa-900038001003": "winreg (Remote Registry)",
    "4b324fc8-1670-01d3-1278-5a47bf6ee188": "srvsvc (Server Service)",
    "45f52c28-7f9f-101a-b52b-08002b2efabe": "winspool (Print Spooler)",
    "76f03f96-cdfd-44fc-a22c-64950a001209": "spoolss (Spooler SubSystem)",
    "12345678-1234-abcd-ef00-0123456789ac": "spoolss (Print Spooler RPC)",
    "6bffd098-a112-3610-9833-46c3f87e345a": "wkssvc (Workstation Service)",
    "1ff70682-0a51-30e8-076d-740be8cee98b": "atsvc (Task Scheduler)",
    "378e52b0-c0a9-11cf-822d-00aa0051e40f": "atsvc (Task Scheduler AT)",
    "86d35949-83c9-4044-b424-db363231fd0c": "atsvc (Task Scheduler 2.0)",
    "3919286a-b10c-11d0-9ba8-00c04fd92ef5": "dssetup (DS Setup)",
    "e3514235-4b06-11d1-ab04-00c04fc2dcd2": "drsuapi (DRS Replication)",
    "4fc742e0-4a10-11cf-8273-00aa004ae673": "dfsnm (DFS Namespace)",
    "c681d488-d850-11d0-8c52-00c04fd90f7e": "efsr (EFS Remote Protocol)",
    "df1941c5-fe89-4e79-bf10-463657acf44d": "efsr (EFSRPC)",
    "c9ac6db5-82b7-4e55-ae8a-e464ed7b4277": "cersvc (ICertPassage)",
    "91ae6020-9e3c-11cf-8d7c-00aa00c091be": "icpr (Certificate Services)",
    "d95afe70-a6d5-4259-822e-2c84da1ddb0d": "wcce (Windows Client Cert Enrollment)",
    "f6beaff7-1e19-4fbb-9f8f-b89e2018337c": "eventlog (Event Log Remoting V2)",
}

# Friendly names for common RPC services
SERVICE_FRIENDLY = {
    "samr": "Security Account Manager",
    "lsarpc": "Local Security Authority",
    "netlogon": "Netlogon",
    "epmapper": "Endpoint Mapper",
    "svcctl": "Service Control Manager",
    "winreg": "Remote Registry",
    "srvsvc": "Server Service",
    "wkssvc": "Workstation Service",
    "spoolss": "Print Spooler",
    "winspool": "Print Spooler",
    "atsvc": "Task Scheduler",
    "drsuapi": "Directory Replication",
    "efsr": "Encrypting File System",
    "dfsnm": "DFS Namespace Management",
    "icpr": "Certificate Services",
    "eventlog": "Event Log",
}

# Ports that indicate specific services are likely running
PORT_SERVICE_MAP = {
    135:   ["epmapper"],
    139:   ["srvsvc", "samr", "lsarpc", "netlogon", "svcctl"],
    445:   ["srvsvc", "samr", "lsarpc", "netlogon", "svcctl", "winreg"],
    593:   ["epmapper"],   # RPC over HTTP
    3268:  ["drsuapi", "samr"],   # Global Catalog
    3269:  ["drsuapi", "samr"],   # GC SSL
    636:   ["samr", "lsarpc"],    # LDAPS
    389:   ["samr", "lsarpc"],    # LDAP
    88:    ["netlogon", "samr"],  # Kerberos → likely DC
    53:    ["netlogon"],          # DNS → might be DC
    9389:  ["drsuapi", "samr"],   # AD Web Services
    5985:  ["svcctl"],            # WinRM
    5986:  ["svcctl"],            # WinRM SSL
    1433:  [],                    # SQL - no RPC inference
    80:    [],
    443:   [],
}

# Minimum services present on ANY reachable Windows host with port 135 open
BASE_WINDOWS_SERVICES = ["epmapper", "svcctl"]

# Services that indicate a Domain Controller specifically
DC_INDICATOR_PORTS = {88, 389, 636, 3268, 3269, 9389}

# Services present on standard (non-DC) Windows Server with SMB
SMB_SERVICES = ["srvsvc", "samr", "lsarpc", "svcctl", "winreg"]

# Services present on DCs in addition to SMB services
DC_EXTRA_SERVICES = ["netlogon", "drsuapi", "wkssvc"]


# Probe timeout in seconds
PROBE_TIMEOUT = 5
PROBE_PORTS = [135, 139, 445, 88, 389, 636, 3268, 3269, 9389, 5985]


class RPCEnumerator:
    """Enumerate RPC endpoints on a target system."""

    def __init__(self, impacket_path: Optional[str] = None):
        self.impacket_path = impacket_path

    def enumerate(self, target: str, port: int = 135,
                  username: str = "", password: str = "",
                  domain: str = "") -> RPCEnumResult:
        """
        Enumerate RPC endpoints using best available method.

        Strategy:
          1. Always probe open ports first (fast TCP connect, no Nmap needed).
          2. Try Impacket for confirmed service listing.
          3. Fall back to raw RPC bind if Impacket unavailable.
          4. ONLY infer services if port 135 (or 445) is confirmed open.
             Never return inferred results for an unreachable host.
        """
        # Step 1: Probe which ports are actually open
        open_ports = self._probe_ports(target)
        port_135_open = 135 in open_ports
        host_reachable = len(open_ports) > 0

        if not host_reachable:
            return RPCEnumResult(
                target=target,
                success=False,
                error="Host appears unreachable — no response on any probed port.",
                host_reachable=False,
                port_135_open=False,
                open_ports=[],
                inferred=False,
            )

        # Step 2: Try Impacket (only if port 135 is open)
        if port_135_open:
            result = self._try_impacket(target, port, username, password, domain)
            if result.success and result.endpoints:
                result.services = self._extract_services(result.endpoints)
                result.host_reachable = True
                result.port_135_open = True
                result.open_ports = list(open_ports)
                result.inferred = False
                return result

            # Step 3: Raw RPC fallback (port 135 confirmed open)
            logger.info("Impacket unavailable or failed, trying raw RPC query...")
            result = self._try_raw_rpc(target, port)
            if result.success and result.endpoints:
                result.host_reachable = True
                result.port_135_open = True
                result.open_ports = list(open_ports)
                result.inferred = False
                return result

        # Step 4: Port-based inference — ONLY because we confirmed the host is alive
        logger.info("Using port-based service inference (host is reachable)...")
        return self._infer_from_ports(target, open_ports)

    def _probe_ports(self, target: str) -> Set[int]:
        """
        Quick TCP connect probe to discover which ports are open.
        Returns set of open port numbers.
        """
        open_ports: Set[int] = set()
        for p in PROBE_PORTS:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(PROBE_TIMEOUT)
                result = sock.connect_ex((target, p))
                sock.close()
                if result == 0:
                    open_ports.add(p)
                    logger.debug(f"Port {p} is open on {target}")
            except Exception as e:
                logger.debug(f"Probe port {p} on {target}: {e}")
        return open_ports

    def _infer_from_ports(self, target: str, open_ports: Set[int]) -> RPCEnumResult:
        """
        Infer RPC services based only on ports confirmed open on this host.
        Never adds services for ports that aren't open.
        """
        inferred_services: Set[str] = set()

        # Port 135 is the core RPC endpoint mapper
        if 135 in open_ports:
            inferred_services.add("epmapper")

        # SMB ports → standard file/print sharing stack
        if 445 in open_ports or 139 in open_ports:
            for svc in SMB_SERVICES:
                inferred_services.add(svc)

        # Kerberos (88) is a strong DC indicator
        is_dc = bool(DC_INDICATOR_PORTS & open_ports)
        if is_dc:
            for svc in DC_EXTRA_SERVICES:
                inferred_services.add(svc)

        # Add port-specific services
        for p in open_ports:
            for svc in PORT_SERVICE_MAP.get(p, []):
                inferred_services.add(svc)

        # If port 135 is open but nothing else, at minimum epmapper + svcctl
        if 135 in open_ports and len(inferred_services) < 2:
            inferred_services.update(BASE_WINDOWS_SERVICES)

        services = sorted(inferred_services)

        endpoints = []
        for svc in services:
            endpoints.append(RPCEndpoint(
                uuid="inferred",
                version="",
                protocol="ncacn_ip_tcp",
                endpoint=f"TCP:{target}[135]",
                service_name=svc,
                annotation=f"Inferred from open ports: {sorted(open_ports)}",
                known_service=SERVICE_FRIENDLY.get(svc, svc),
                confirmed=False,
            ))

        return RPCEnumResult(
            target=target,
            endpoints=endpoints,
            services=services,
            success=True,
            method="port_inference",
            host_reachable=True,
            port_135_open=(135 in open_ports),
            open_ports=sorted(open_ports),
            inferred=True,
        )

    def _infer_services(self, target: str, method: str = "inference") -> RPCEnumResult:
        """
        Legacy method kept for offline tests.
        In the live pipeline, use _infer_from_ports() instead.
        """
        standard_services = [
            "epmapper", "samr", "lsarpc", "netlogon",
            "srvsvc", "wkssvc", "svcctl", "winreg",
        ]
        endpoints = []
        for svc in standard_services:
            endpoints.append(RPCEndpoint(
                uuid="inferred",
                version="",
                protocol="ncacn_ip_tcp",
                endpoint=f"TCP:{target}[135]",
                service_name=svc,
                annotation="Inferred from standard Windows RPC configuration",
                known_service=SERVICE_FRIENDLY.get(svc, svc),
                confirmed=False,
            ))
        return RPCEnumResult(
            target=target, endpoints=endpoints,
            services=standard_services,
            success=True, method=method,
            inferred=True,
        )

    def _try_impacket(self, target: str, port: int,
                      username: str, password: str,
                      domain: str) -> RPCEnumResult:
        """Enumerate using Impacket rpcdump."""
        try:
            from impacket.dcerpc.v5 import transport, epm
            from impacket.dcerpc.v5.rpcrt import RPC_C_AUTHN_LEVEL_NONE

            string_binding = f"ncacn_ip_tcp:{target}[{port}]"
            rpctransport = transport.DCERPCTransportFactory(string_binding)

            if username:
                rpctransport.set_credentials(username, password, domain)

            dce = rpctransport.get_dce_rpc()
            dce.set_auth_level(RPC_C_AUTHN_LEVEL_NONE)
            dce.connect()

            entries = epm.hept_lookup(None, dce=dce)

            endpoints = []
            for entry in entries:
                uuid_str = entry["tower"]["Floors"][0]["uuid"]
                version = entry["tower"]["Floors"][0].get("version", "")
                protocol = str(entry["tower"]["Floors"][2])
                endpoint_addr = str(entry["tower"]["Floors"][3])
                annotation = entry.get("annotation", b"").decode("utf-8", errors="ignore")
                known = self._identify_service(str(uuid_str))
                endpoints.append(RPCEndpoint(
                    uuid=str(uuid_str),
                    version=str(version),
                    protocol=protocol,
                    endpoint=endpoint_addr,
                    service_name=known.split(" ")[0] if known else "",
                    annotation=annotation,
                    known_service=known,
                    confirmed=True,
                ))

            dce.disconnect()
            return RPCEnumResult(
                target=target, endpoints=endpoints,
                success=True, method="impacket_api"
            )

        except ImportError:
            logger.debug("Impacket not installed, trying CLI...")
        except Exception as e:
            logger.debug(f"Impacket API failed: {e}")

        return self._try_impacket_cli(target, port, username, password, domain)

    def _try_impacket_cli(self, target: str, port: int,
                          username: str, password: str,
                          domain: str) -> RPCEnumResult:
        """Enumerate using rpcdump.py CLI."""
        rpcdump = self.impacket_path or shutil.which("rpcdump.py")
        if not rpcdump:
            rpcdump = shutil.which("rpcdump")
        if not rpcdump:
            return RPCEnumResult(
                target=target, success=False,
                error="rpcdump not found", method="impacket_cli"
            )

        cmd = [rpcdump, f"{target}"]
        if port != 135:
            cmd.extend(["-port", str(port)])
        if username:
            cred = f"{domain + '/' if domain else ''}{username}:{password}"
            cmd.insert(1, cred)

        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=60
            )
            return self._parse_rpcdump_output(target, proc.stdout)
        except Exception as e:
            return RPCEnumResult(
                target=target, success=False,
                error=str(e), method="impacket_cli"
            )

    def _parse_rpcdump_output(self, target: str, output: str) -> RPCEnumResult:
        """Parse rpcdump text output."""
        endpoints = []
        current_uuid = None

        for line in output.splitlines():
            line = line.strip()
            uuid_match = re.match(r"Protocol:\s+\[(.+?)\]\s+(.+?)$", line)
            if uuid_match:
                protocol = uuid_match.group(1)
                endpoint = uuid_match.group(2)
                if current_uuid:
                    known = self._identify_service(current_uuid)
                    endpoints.append(RPCEndpoint(
                        uuid=current_uuid,
                        version="",
                        protocol=protocol,
                        endpoint=endpoint,
                        service_name=known.split(" ")[0] if known else "",
                        known_service=known,
                        confirmed=True,
                    ))
                continue

            prov_match = re.match(
                r"Provider:\s+.+?\s+UUID:\s+([0-9a-f-]+)\s+v([\d.]+)", line, re.I
            )
            if prov_match:
                current_uuid = prov_match.group(1).lower()

        return RPCEnumResult(
            target=target, endpoints=endpoints,
            success=True, method="impacket_cli"
        )

    def _try_raw_rpc(self, target: str, port: int) -> RPCEnumResult:
        """Attempt raw RPC endpoint mapper query using TCP."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            sock.connect((target, port))

            bind_packet = self._build_rpc_bind()
            sock.send(bind_packet)
            resp = sock.recv(4096)
            sock.close()

            if len(resp) < 24:
                return RPCEnumResult(
                    target=target, success=False,
                    error="Invalid RPC response", method="raw_rpc"
                )

            # Got a valid bind_ack — host is definitely running RPC
            # But we still can't enumerate services from this alone;
            # fall through to port-based inference by returning success=False
            # so enumerate() proceeds to _infer_from_ports.
            return RPCEnumResult(
                target=target, success=False,
                error="RPC bind succeeded but full endpoint listing requires Impacket",
                method="raw_rpc"
            )

        except Exception as e:
            return RPCEnumResult(
                target=target, success=False,
                error=str(e), method="raw_rpc"
            )

    def _build_rpc_bind(self) -> bytes:
        """Build minimal DCE/RPC bind packet for Endpoint Mapper."""
        epm_uuid = bytes.fromhex("0831afe11f5dc91191a408002b14a0fa")
        header = struct.pack("<BBBBIHHI",
            5, 0, 11, 3, 0x10, 72, 0, 0,
        )
        bind_body = struct.pack("<HHI", 4096, 4096, 0)
        ctx = struct.pack("<IHH", 1, 0, 1)
        ctx += epm_uuid
        ctx += struct.pack("<HH", 3, 0)
        ndr_uuid = bytes.fromhex("045d888aeb1cc9119fe808002b104860")
        ctx += ndr_uuid
        ctx += struct.pack("<HH", 2, 0)
        packet = header + bind_body + ctx
        packet = packet[:8] + struct.pack("<H", len(packet)) + packet[10:]
        return packet

    def _identify_service(self, uuid: str) -> str:
        """Look up a UUID to determine the service name."""
        return KNOWN_RPC_UUIDS.get(uuid.lower().strip(), "")

    def _extract_services(self, endpoints: List[RPCEndpoint]) -> List[str]:
        """Extract unique service names from endpoints."""
        services = set()
        for ep in endpoints:
            if ep.service_name:
                services.add(ep.service_name)
        return sorted(services)
