"""
recommender.py - Security recommendation engine.
Generates prioritized, actionable remediation guidance.
"""

import logging
from typing import Dict, List, Any
from dataclasses import dataclass, field, asdict

logger = logging.getLogger(__name__)


@dataclass
class Recommendation:
    """A single security recommendation."""
    priority: int           # 1 = highest
    severity: str           # Critical/High/Medium/Low
    category: str           # Patch/Config/Network/Monitor
    title: str
    description: str
    affected_cves: List[str] = field(default_factory=list)
    affected_services: List[str] = field(default_factory=list)
    effort: str = "Medium"  # Low/Medium/High
    impact: str = "High"    # Risk reduction impact

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# Service-specific remediation templates
SERVICE_REMEDIATIONS = {
    "spoolss": [
        {
            "category": "Config",
            "title": "Disable Print Spooler on Domain Controllers",
            "description": (
                "The Print Spooler service (spoolsv.exe) should be disabled on all "
                "domain controllers and servers that do not require printing. "
                "Run: Stop-Service Spooler; Set-Service Spooler -StartupType Disabled"
            ),
            "effort": "Low",
            "impact": "Critical",
        },
        {
            "category": "Config",
            "title": "Restrict Print Spooler Remote Access via GPO",
            "description": (
                "Configure Group Policy to restrict Print Spooler remote connections: "
                "Computer Config > Admin Templates > Printers > "
                "Allow Print Spooler to accept client connections = Disabled"
            ),
            "effort": "Low",
            "impact": "High",
        },
    ],
    "winspool": [
        {
            "category": "Config",
            "title": "Disable Print Spooler Service",
            "description": "Disable spoolsv.exe on non-print servers. PowerShell: Stop-Service Spooler; Set-Service Spooler -StartupType Disabled",
            "effort": "Low",
            "impact": "Critical",
        },
    ],
    "netlogon": [
        {
            "category": "Patch",
            "title": "Apply Zerologon Patch Immediately",
            "description": (
                "Install KB4571694 or later cumulative update on ALL domain controllers. "
                "Enable enforcement mode via registry: "
                "HKLM\\SYSTEM\\CurrentControlSet\\Services\\Netlogon\\Parameters\\FullSecureChannelProtection = 1"
            ),
            "effort": "Medium",
            "impact": "Critical",
        },
        {
            "category": "Monitor",
            "title": "Monitor Netlogon Authentication Events",
            "description": (
                "Enable advanced auditing for Netlogon events. "
                "Watch for Event ID 5829 (vulnerable Netlogon secure channel connection). "
                "Set up alerts for anomalous authentication patterns."
            ),
            "effort": "Medium",
            "impact": "High",
        },
    ],
    "samr": [
        {
            "category": "Config",
            "title": "Restrict SAM Remote Enumeration",
            "description": (
                "Configure Network access: Restrict clients allowed to make remote calls to SAM. "
                "Set via GPO: O:BAG:BAD:(A;;RC;;;BA) to allow only Built-in Administrators. "
                "This blocks anonymous SAM enumeration."
            ),
            "effort": "Low",
            "impact": "High",
        },
    ],
    "lsarpc": [
        {
            "category": "Config",
            "title": "Enable Extended Protection for Authentication (EPA)",
            "description": (
                "Configure EPA on domain controllers to prevent NTLM relay attacks. "
                "Enable channel binding and service binding for LDAP, HTTP, and RPC."
            ),
            "effort": "Medium",
            "impact": "High",
        },
        {
            "category": "Config",
            "title": "Disable NTLM Where Possible",
            "description": (
                "Transition to Kerberos authentication. Set GPO: "
                "Network security: Restrict NTLM: Audit/Deny incoming/outgoing NTLM traffic. "
                "Start with audit mode, then enforce restrictions."
            ),
            "effort": "High",
            "impact": "Critical",
        },
    ],
    "svcctl": [
        {
            "category": "Config",
            "title": "Restrict Remote Service Control Manager Access",
            "description": (
                "Harden SCM permissions to prevent remote service manipulation. "
                "Limit remote access to service control manager via firewall rules and ACLs."
            ),
            "effort": "Medium",
            "impact": "High",
        },
    ],
    "winreg": [
        {
            "category": "Config",
            "title": "Disable Remote Registry Service",
            "description": (
                "Disable the Remote Registry service on all systems where it is not required. "
                "PowerShell: Stop-Service RemoteRegistry; Set-Service RemoteRegistry -StartupType Disabled"
            ),
            "effort": "Low",
            "impact": "Medium",
        },
    ],
    "srvsvc": [
        {
            "category": "Config",
            "title": "Disable SMBv1 Protocol",
            "description": (
                "Disable SMBv1 on all systems: "
                "Set-SmbServerConfiguration -EnableSMB1Protocol $false. "
                "Remove SMBv1 feature: Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol"
            ),
            "effort": "Low",
            "impact": "Critical",
        },
        {
            "category": "Patch",
            "title": "Apply MS17-010 and SMBGhost Patches",
            "description": "Ensure KB4013389 (MS17-010) and KB4551762 (SMBGhost) are installed on all systems.",
            "effort": "Medium",
            "impact": "Critical",
        },
    ],
    "drsuapi": [
        {
            "category": "Config",
            "title": "Restrict Replication Permissions",
            "description": (
                "Audit and restrict \"Replicating Directory Changes\" and "
                "\"Replicating Directory Changes All\" permissions. "
                "Only domain controllers and authorized service accounts should have these rights."
            ),
            "effort": "Medium",
            "impact": "Critical",
        },
        {
            "category": "Monitor",
            "title": "Monitor for DCSync Activity",
            "description": (
                "Enable auditing for Event ID 4662 with GUID "
                "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2 (DS-Replication-Get-Changes). "
                "Alert on non-DC sources performing replication."
            ),
            "effort": "Medium",
            "impact": "High",
        },
    ],
    "efsr": [
        {
            "category": "Config",
            "title": "Block EFS RPC Coercion (PetitPotam)",
            "description": (
                "Apply KB5005413 and configure RPC filters to block EfsRpcOpenFileRaw. "
                "Use netsh rpc filter to block EFS RPC calls from untrusted sources."
            ),
            "effort": "Medium",
            "impact": "High",
        },
    ],
    "atsvc": [
        {
            "category": "Config",
            "title": "Restrict Remote Task Scheduler Access",
            "description": (
                "Limit remote access to Task Scheduler via firewall and GPO. "
                "Remove unnecessary scheduled tasks. Monitor Task Scheduler event logs."
            ),
            "effort": "Low",
            "impact": "Medium",
        },
    ],
    "dfsnm": [
        {
            "category": "Config",
            "title": "Restrict DFS Namespace Management RPC",
            "description": (
                "Apply patches for CVE-2022-26925. Filter RPC calls to DFS management interfaces. "
                "Consider disabling DFS if not in use."
            ),
            "effort": "Medium",
            "impact": "High",
        },
    ],
}

# General recommendations that always apply
GENERAL_RECOMMENDATIONS = [
    {
        "category": "Network",
        "title": "Restrict RPC Port 135 via Firewall",
        "description": (
            "Block port 135/TCP from untrusted networks. Use Windows Firewall with "
            "Advanced Security or network firewalls to limit RPC access to authorized "
            "management subnets only."
        ),
        "effort": "Low",
        "impact": "High",
    },
    {
        "category": "Network",
        "title": "Implement Network Segmentation",
        "description": (
            "Segment domain controllers and sensitive servers into isolated VLANs. "
            "Use jump servers/PAWs for administrative access. "
            "Block direct RPC access from user segments."
        ),
        "effort": "High",
        "impact": "Critical",
    },
    {
        "category": "Patch",
        "title": "Maintain Patch Compliance",
        "description": (
            "Ensure all Windows systems are current on security updates. "
            "Implement a 30-day patch cycle for critical updates and 90-day for others. "
            "Use WSUS/SCCM/Intune for centralized management."
        ),
        "effort": "Medium",
        "impact": "High",
    },
    {
        "category": "Monitor",
        "title": "Deploy RPC Traffic Monitoring",
        "description": (
            "Implement network detection for anomalous RPC traffic. "
            "Use tools like Zeek/Suricata with RPC protocol analyzers. "
            "Alert on unusual RPC endpoint access patterns."
        ),
        "effort": "High",
        "impact": "High",
    },
    {
        "category": "Config",
        "title": "Enable RPC Packet-Level Security",
        "description": (
            "Configure RPC to require packet-level authentication and encryption. "
            "Set via GPO: Network security: Minimum session security for NTLM. "
            "Require NTLMv2 and 128-bit encryption."
        ),
        "effort": "Low",
        "impact": "Medium",
    },
]


class RecommendationEngine:
    """Generate prioritized security recommendations."""

    def generate(self, risk_summary: Any, vulnerabilities: list) -> List[Recommendation]:
        """
        Generate recommendations based on risk analysis results.

        Args:
            risk_summary: RiskSummary from analyzer
            vulnerabilities: List of Vulnerability objects
        """
        recommendations = []
        priority = 1

        # 1. Service-specific recommendations (highest priority)
        services_covered = set()
        for vuln in sorted(vulnerabilities, key=lambda v: v.cvss_score, reverse=True):
            svc = vuln.affected_service
            if svc in services_covered:
                continue
            services_covered.add(svc)

            templates = SERVICE_REMEDIATIONS.get(svc, [])
            for tmpl in templates:
                svc_cves = [v.cve_id for v in vulnerabilities if v.affected_service == svc]
                recommendations.append(Recommendation(
                    priority=priority,
                    severity=vuln.severity,
                    category=tmpl["category"],
                    title=tmpl["title"],
                    description=tmpl["description"],
                    affected_cves=svc_cves,
                    affected_services=[svc],
                    effort=tmpl.get("effort", "Medium"),
                    impact=tmpl.get("impact", "High"),
                ))
                priority += 1

        # 2. Patch recommendations for specific CVEs
        patched_cves = set()
        for vuln in vulnerabilities:
            if vuln.microsoft_kb and vuln.cve_id not in patched_cves:
                patched_cves.add(vuln.cve_id)
                recommendations.append(Recommendation(
                    priority=priority,
                    severity=vuln.severity,
                    category="Patch",
                    title=f"Install {vuln.microsoft_kb} for {vuln.cve_id}",
                    description=f"Apply Microsoft update {vuln.microsoft_kb} to remediate {vuln.title} (CVSS {vuln.cvss_score}).",
                    affected_cves=[vuln.cve_id],
                    affected_services=[vuln.affected_service],
                    effort="Medium",
                    impact=vuln.severity,
                ))
                priority += 1

        # 3. General recommendations
        for tmpl in GENERAL_RECOMMENDATIONS:
            recommendations.append(Recommendation(
                priority=priority,
                severity="Medium",
                category=tmpl["category"],
                title=tmpl["title"],
                description=tmpl["description"],
                effort=tmpl.get("effort", "Medium"),
                impact=tmpl.get("impact", "High"),
            ))
            priority += 1

        # Deduplicate by title
        seen_titles = set()
        unique = []
        for rec in recommendations:
            if rec.title not in seen_titles:
                seen_titles.add(rec.title)
                unique.append(rec)

        return unique

    def get_executive_summary(self, risk_summary: Any,
                              recommendations: List[Recommendation]) -> str:
        """Generate an executive summary paragraph."""
        level = risk_summary.overall_risk_level
        target = risk_summary.target
        vuln_count = risk_summary.unique_cves
        highest = risk_summary.highest_cvss
        avg = risk_summary.average_cvss
        exploitable = risk_summary.exploitable_count

        critical_recs = [r for r in recommendations if r.severity == "Critical"]
        high_recs = [r for r in recommendations if r.severity == "High"]

        summary = (
            f"The RPC risk assessment of {target} identified {vuln_count} unique vulnerabilities "
            f"with an average CVSS score of {avg} and a maximum score of {highest}. "
            f"The overall risk level is {level}. "
        )

        if exploitable:
            summary += f"{exploitable} vulnerabilities have known public exploits. "

        if critical_recs:
            summary += (
                f"{len(critical_recs)} critical remediation actions are recommended "
                f"for immediate implementation. "
            )

        if level in ("CRITICAL", "HIGH"):
            summary += (
                "Immediate action is required to reduce the attack surface. "
                "Priority should be given to patching, disabling unnecessary services, "
                "and implementing network segmentation."
            )
        elif level in ("MEDIUM-HIGH", "MEDIUM"):
            summary += (
                "Remediation should be prioritized within the next patching cycle. "
                "Focus on restricting RPC access and applying pending security updates."
            )
        else:
            summary += (
                "Continue regular security maintenance and monitoring. "
                "Ensure RPC services are restricted to authorized networks."
            )

        return summary
