from rpc_riskmapper.main import main
main()
