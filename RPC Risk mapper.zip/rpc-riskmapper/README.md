# 🛡 RPC RiskMapper

**RPC-based Network Risk Assessment Tool with CVSS Vulnerability Scoring**

A professional-grade, modular CLI tool that scans target systems, identifies RPC services (especially on port 135), maps discovered services to known vulnerabilities, calculates risk using CVSS v3.x scores, and provides actionable security recommendations.

---

## Features

- **Network Scanning** — Nmap-based scanning focused on RPC ports (135, 139, 445, 593, dynamic RPC)
- **RPC Endpoint Enumeration** — Impacket rpcdump integration with raw RPC fallback
- **Local CVE Database** — 20+ major RPC vulnerabilities (PrintNightmare, Zerologon, PetitPotam, EternalBlue, SMBGhost, Certifried, etc.)
- **CVSS v3.x Scoring** — Full vector breakdown (AV/AC/PR/UI/S/C/I/A)
- **Risk Analysis Engine** — Weighted scoring, severity distribution, exploitability assessment
- **MITRE ATT&CK Mapping** — Techniques mapped to discovered vulnerabilities
- **Recommendation Engine** — Prioritized, service-specific remediation guidance
- **Multiple Report Formats** — Console (colored), JSON, HTML
- **NVD API Integration** — Optional enrichment from NIST National Vulnerability Database
- **Local CVE Caching** — 24-hour cache for NVD results

---

## Installation

### Prerequisites

- **Python 3.8+**
- **Nmap** — Download from [https://nmap.org/download.html](https://nmap.org/download.html)
- **Windows 10/11** or **Windows Server 2016+**

### Install from source

```cmd
git clone https://github.com/your-org/rpc-riskmapper.git
cd rpc-riskmapper
pip install -r requirements.txt
```

### Install as package

```cmd
pip install .
```

### Install as editable (development)

```cmd
pip install -e .
```

---

## Usage

### Basic Scan

```cmd
python -m rpc_riskmapper 192.168.1.10
```

or after installation:

```cmd
rpc-riskmapper 192.168.1.10
```

### Aggressive Scan with Reports

```cmd
rpc-riskmapper 192.168.1.10 --aggressive --json report.json --html report.html
```

### Authenticated Scan

```cmd
rpc-riskmapper dc01.corp.local -u admin -P password -d CORP
```

### Offline Mode (Skip Nmap)

```cmd
rpc-riskmapper 192.168.1.10 --offline
```

### With NVD API Enrichment

```cmd
rpc-riskmapper 10.0.0.5 --use-nvd --nvd-api-key YOUR_API_KEY
```

### All Options

```
usage: rpc-riskmapper [-h] [--ports PORTS] [--aggressive] [--timeout TIMEOUT]
                      [--no-scripts] [--nmap-path NMAP_PATH] [--offline]
                      [--username USERNAME] [--password PASSWORD] [--domain DOMAIN]
                      [--use-nvd] [--nvd-api-key KEY] [--custom-db PATH]
                      [--json FILE] [--html FILE] [--no-color] [--quiet] [--verbose]
                      target
```

---

## Output Example

```
  Target: 192.168.1.10

  Findings:
    RPC Port 135 is open
    Service detected: samr, netlogon, spoolss

  Vulnerabilities:
    CVE-2020-1472 (Zerologon)       CVSS: 10.0 [CRITICAL] ⚠ EXPLOIT AVAILABLE
    CVE-2021-34527 (PrintNightmare)  CVSS: 8.8  [HIGH]     ⚠ EXPLOIT AVAILABLE
    CVE-2021-36942 (PetitPotam)      CVSS: 7.5  [HIGH]     ⚠ EXPLOIT AVAILABLE

  Risk Summary:
    Average CVSS:       8.5
    Highest CVSS:       10.0 (CVE-2020-1472)
    Overall Risk Level: CRITICAL

  Recommendations:
    1. [CRITICAL] Apply Zerologon Patch Immediately (KB4571694)
    2. [HIGH] Disable Print Spooler on Domain Controllers
    3. [HIGH] Block EFS RPC Coercion (PetitPotam)
    4. [MEDIUM] Restrict RPC Port 135 via Firewall
    5. [MEDIUM] Implement Network Segmentation
```

---

## Project Structure

```
rpc-riskmapper/
├── rpc_riskmapper/
│   ├── __init__.py        # Package metadata
│   ├── __main__.py        # python -m entry point
│   ├── main.py            # CLI entry point & pipeline orchestration
│   ├── scanner.py         # Nmap network scanning
│   ├── rpc_enum.py        # RPC endpoint enumeration
│   ├── vuln_lookup.py     # CVE database & CVSS lookup
│   ├── analyzer.py        # Risk analysis engine
│   ├── recommender.py     # Recommendation generator
│   └── reporter.py        # Console/JSON/HTML report output
├── tests/
│   └── test_offline.py    # Offline test suite
├── data/                  # Custom CVE databases (optional)
├── reports/               # Generated reports output
├── requirements.txt
├── setup.py
├── pyproject.toml
└── README.md
```

---

## Exit Codes

| Code | Risk Level    |
|------|---------------|
| 0    | Informational |
| 1    | Low           |
| 2    | Medium        |
| 3    | High          |
| 4    | Critical      |

---

## Custom CVE Database

Create a JSON file mapping service names to vulnerabilities:

```json
{
  "my_service": [
    {
      "cve_id": "CVE-2024-XXXXX",
      "title": "My Custom Vulnerability",
      "description": "Description here",
      "cvss_score": 8.5,
      "cvss_version": "3.1",
      "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
      "mitre": ["T1210"],
      "exploit_available": false,
      "kb": "KB1234567"
    }
  ]
}
```

Use with: `rpc-riskmapper target --custom-db my_cves.json`

---

## License

MIT License

---

## Disclaimer

This tool is for **authorized security testing only**. Unauthorized scanning of networks you do not own or have explicit permission to test is illegal. Always obtain proper authorization before conducting security assessments.
