"""
Offline test suite for RPC RiskMapper.
Tests core logic without requiring network access or Nmap.
"""

import sys
import os

# Support running directly or as part of the package
_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _root not in sys.path:
    sys.path.insert(0, _root)

from rpc_riskmapper.vuln_lookup import VulnerabilityLookup, classify_severity, parse_cvss_vector
from rpc_riskmapper.analyzer import RiskAnalyzer
from rpc_riskmapper.recommender import RecommendationEngine
from rpc_riskmapper.rpc_enum import RPCEnumerator


def test_severity_classification():
    assert classify_severity(10.0) == "Critical"
    assert classify_severity(9.0) == "Critical"
    assert classify_severity(8.5) == "High"
    assert classify_severity(7.0) == "High"
    assert classify_severity(6.9) == "Medium"
    assert classify_severity(4.0) == "Medium"
    assert classify_severity(3.9) == "Low"
    assert classify_severity(0.1) == "Low"
    assert classify_severity(0.0) == "Informational"
    print("[PASS] Severity classification")


def test_cvss_vector_parsing():
    vec = parse_cvss_vector("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H")
    assert vec.attack_vector == "Network"
    assert vec.attack_complexity == "Low"
    assert vec.privileges_required == "None"
    assert vec.user_interaction == "None"
    assert vec.scope == "Changed"
    assert vec.confidentiality == "High"
    assert vec.integrity == "High"
    assert vec.availability == "High"
    print("[PASS] CVSS vector parsing")


def test_vulnerability_lookup():
    lookup = VulnerabilityLookup()
    vulns = lookup.lookup(["netlogon", "spoolss", "samr"])
    assert len(vulns) > 0
    cve_ids = [v.cve_id for v in vulns]
    assert "CVE-2020-1472" in cve_ids, "Zerologon should be found"
    assert "CVE-2021-34527" in cve_ids, "PrintNightmare should be found"
    # Check deduplication
    assert len(cve_ids) == len(set(cve_ids)), "CVEs should be deduplicated"
    print(f"[PASS] Vulnerability lookup ({len(vulns)} vulns found)")


def test_risk_analysis():
    lookup = VulnerabilityLookup()
    vulns = lookup.lookup(["netlogon", "spoolss", "srvsvc"])
    analyzer = RiskAnalyzer()
    summary = analyzer.analyze("test-target", vulns)
    assert summary.overall_risk_level == "CRITICAL"
    assert summary.highest_cvss == 10.0
    assert summary.unique_cves > 0
    assert summary.exploitable_count > 0
    print(f"[PASS] Risk analysis (level={summary.overall_risk_level}, score={summary.weighted_risk_score})")


def test_recommendations():
    lookup = VulnerabilityLookup()
    vulns = lookup.lookup(["netlogon", "spoolss"])
    analyzer = RiskAnalyzer()
    summary = analyzer.analyze("test-target", vulns)
    engine = RecommendationEngine()
    recs = engine.generate(summary, vulns)
    assert len(recs) > 0
    exec_sum = engine.get_executive_summary(summary, recs)
    assert len(exec_sum) > 50
    print(f"[PASS] Recommendations ({len(recs)} generated)")


def test_rpc_inference():
    enum = RPCEnumerator()
    result = enum._infer_services("192.168.1.1")
    assert result.success
    assert len(result.services) > 0
    assert "samr" in result.services
    print(f"[PASS] RPC inference ({len(result.services)} services)")


def test_full_offline_pipeline():
    """Full pipeline test without network."""
    enum = RPCEnumerator()
    rpc_result = enum._infer_services("10.0.0.1")

    lookup = VulnerabilityLookup()
    vulns = lookup.lookup(rpc_result.services)

    analyzer = RiskAnalyzer()
    summary = analyzer.analyze("10.0.0.1", vulns, rpc_result=rpc_result)

    engine = RecommendationEngine()
    recs = engine.generate(summary, vulns)

    assert summary.unique_cves > 0
    assert summary.overall_risk_level in ("CRITICAL", "HIGH", "MEDIUM-HIGH", "MEDIUM")
    assert len(recs) > 0
    print(f"[PASS] Full pipeline: {summary.unique_cves} CVEs, {len(recs)} recs, risk={summary.overall_risk_level}")


if __name__ == "__main__":
    print("=" * 55)
    print("  RPC RiskMapper - Offline Test Suite")
    print("=" * 55)
    test_severity_classification()
    test_cvss_vector_parsing()
    test_vulnerability_lookup()
    test_risk_analysis()
    test_recommendations()
    test_rpc_inference()
    test_full_offline_pipeline()
    print("=" * 55)
    print("  All tests passed!")
    print("=" * 55)
