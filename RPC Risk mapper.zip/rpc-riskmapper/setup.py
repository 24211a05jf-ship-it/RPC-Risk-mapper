from setuptools import setup, find_packages

setup(
    name="rpc-riskmapper",
    version="1.0.0",
    description="RPC-based Network Risk Assessment Tool with CVSS Vulnerability Scoring",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
    extras_require={
        "full": [
            "python-nmap>=0.7.1",
            "impacket>=0.10.0",
        ]
    },
    entry_points={
        "console_scripts": [
            "rpc-riskmapper=rpc_riskmapper.main:main",
        ]
    },
)
